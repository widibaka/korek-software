<?php
exit();

/* the structure of banlog is:

IP {comma} Remote Host {newline}
or:
xxx.xxx.xxx.xxx,remotehost

It is possible to put an IP address alone (no comma needed, only newline).

It is NOT possible to put in a Remote Host by itself (if you have the
remote host information, getting the IP is simple).

banlog.php is designed to be updated by the script and is not designed for manual editing.

*/


?>

24.61.4.214,c-24-61-4-214.hsd1.ma.comcast.net
58.65.237.161,58-65-237-161.myrdns.com
61.144.122.45,ad.gd.vnet.cn
65.110.59.70,unknown.sagonet.net
66.118.220.27,mail3.brainstorminternet.net
66.79.162.188,66.79.162.188
67.168.130.99,c-67-168-130-99.hsd1.wa.comcast.net
68.3.96.171,ip68-3-96-171.ph.ph.cox.net
69.124.2.98,ool-457c0262.dyn.optonline.net
69.50.175.186
69.88.144.161,NET-allocation-00025844.ix.sitestream.net
69.88.144.162,NET-allocation-00025844.ix.sitestream.net
69.88.144.163,NET-allocation-00025844.ix.sitestream.net
70.39.217.51,70-39-217-51.clvdoh.adelphia.net
71.146.1.77,adsl-71-146-1-77.dsl.pltn13.sbcglobal.net
71.233.250.204,c-71-233-250-204.hsd1.ma.comcast.net
74.134.234.239,74-134-234-239.dhcp.insightbb.com
75.64.147.96,c-75-64-147-96.hsd1.tn.comcast.net
81.169.140.61,h115080.serverkompetenz.net
82.76.180.177,82-76-180-177.rdsnet.ro
83.133.119.38,83.133.119.38
83.22.15.81,duh81.neoplus.adsl.tpnet.pl
83.243.91.9,83.243.91.9
84.19.184.204,ns.km20926-03.keymachine.de
84.205.2.153,CMPC002-153.CNet2.Gawex.PL
84.251.99.154,dsl-vsabrasgw1-fe63fb00-154.dhcp.inet.fi
85.140.151.21,ppp85-140-151-21.pppoe.mtu-net.ru
85.214.45.212,edv-na.de
88.162.73.4,voi38-2-88-162-73-4.fbx.proxad.net
88.224.248.141
89.223.1.69,89.223.1.69
91.124.23.33,33-23-124-91.pool.ukrtel.net
125.243.159.2,125.243.159.2
125.243.251.210,125.243.251.210
125.243.92.66,125.243.92.66
125.244.108.4,125.244.108.4
125.244.110.66,125.244.110.66
125.244.115.140,125.244.115.140
125.244.115.145,125.244.115.145
125.244.179.66,125.244.179.66
125.244.24.2,125.244.24.2
125.244.72.2,125.244.72.2
125.244.76.130,125.244.76.130
125.245.210.66,125.245.210.66
125.248.152.26,125.248.152.26
125.248.244.131,125.248.244.131
125.7.203.168
127.0.0.3,s2.hmnoc.net
144.140.22.190,144.140.22.190
159.148.3.187,159.148.3.187
165.139.16.1,border.msdwc.k12.in.us
165.228.128.11,civ-cache1-1.cache.telstra.net
165.228.131.12,cha-cache2-1.cache.telstra.net
165.228.132.11,way-cache1-1.cache.telstra.net
193.111.244.21,ibm.telenet.lv
195.175.37.6,195.175.37.6
195.175.37.8,195.175.37.8
200.30.104.46
200.88.125.9,tdev125-9.codetel.net.do
200.88.223.99,tdev223-99.codetel.net.do
202.29.60.165,202.29.60.165
203.113.15.234
203.144.143.8,203-144-143-8.static.asianet.co.th
203.26.206.130,bfc9000.internode.on.net
208.102.150.95,MH-ESR1-208-102-150-95.fuse.net
208.27.212.24,208.27.212.24
212.98.164.54,212.98.164.54.bn.by
213.178.224.161,proxy2.aloola.sy
213.230.130.54,213.230.130.54
216.133.248.226,216.133.248.226
216.133.248.227,216.133.248.227
216.133.248.228,216.133.248.228
216.133.248.229,216.133.248.229
216.133.248.230,216.133.248.230
216.144.225.74,mail.extremeassociates.com
216.32.80.234,234.80.32.216.reverse.layeredtech.com
216.32.80.234,234.80.32.216.static.reverse.layeredtech.com
218.108.64.166,218.108.64.166
218.12.76.101
220.225.146.132,220.225.146.132
220.226.63.254
220.226.63.254,220.226.63.254
220.227.133.75,220.227.133.75
220.227.77.186,220.227.77.186
